=== Similar Posts ===
Contributors: Julien C.
Tags: posts, related, tags, post-plugins, query, inside, wp query, list, WP_Query, custom
Requires at least: 2.5
Tested up to: 2.5
Stable tag: 0.3
Displays a custom list of posts to the current one.

== Description ==

Displays a *custom list* of **posts** to the current one. It use the new **Shortcode API** of WP2.5 and the **WP_Query**

[More infos](http://www.webinventif.fr/query-inside-post-plugin-wordpress-pour-inserer-facilement-une-boucle-dans-un-billet/).

== Installation ==

1. Upload the plugin folder to your /wp-content/plugins/ folder.

1. Go to the **Plugins** page and activate the plugin.

1. Put `[wlist]` at the place in your posts where you want the custom list of posts to appear.

[My web site](http://www.webinventif.fr/q) has [full instructions](http://www.webinventif.fr/query-inside-post-plugin-wordpress-pour-inserer-facilement-une-boucle-dans-un-billet/)

== Version History ==

* 0.3
	* first public release

